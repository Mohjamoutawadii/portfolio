import React from "react";


function Footer(){

    return(
        <div className="container-fluid footer pt-3 mt-5 fixed-bottom" style={{backgroundColor:'#2a4696'}}>
            <div className="p-row">
                <div className="p-col-12 text-center justify-content-center">
                    <p style={{color:'white'}}>Made by ERRAJI Abdelmonaim.</p>
                </div>
            </div>

        </div>

    )

}
export default Footer;